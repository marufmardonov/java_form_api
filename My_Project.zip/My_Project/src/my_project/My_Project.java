/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package my_project;

import Login.Login_Page;

/**
 *
 * @author UNDEFINED
 */
public class My_Project {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Login_Page loginObj = new Login_Page();
        loginObj.show();
    }
    
}
